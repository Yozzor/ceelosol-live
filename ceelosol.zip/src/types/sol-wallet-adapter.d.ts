declare module '@project-serum/sol-wallet-adapter';
